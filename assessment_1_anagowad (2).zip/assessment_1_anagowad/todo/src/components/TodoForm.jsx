import React, { Component } from 'react';

class TodoForm extends Component {
    state = {
        text: '',
        status: 'open',
        priority: 1
    };
    constructor() {
        super();
        this.tfChangeHandler = this.tfChangeHandler.bind(this);
    }

    submitHandler = (evt) => {
        evt.preventDefault();
        console.log("text in submit", this.state.text);
        //clear the form element by resetting the state
        this.props.addTodo({ ...this.state});
        this.setState({
            text: '',
            status: 'open',
            priority: 1
        });
        
    }
    tfChangeHandler(evt) {
        let { name, value } = evt.target;
        this.setState({ [name]: value })
    }
    render() {
        return (
            <div>
                <form onSubmit={this.submitHandler}>
                    <div className='container'>
                        <div className="row">
                            <div className="col">
                                < input type="text" id="text" className="form-control" name="text" autoFocus
                                    value={this.state.text} onChange={this.tfChangeHandler} />
                                <p></p>
                            </div >
                            <div className="col-md-2">
                                <button className="btn btn-primary">Add Todo</button>

                            </div>
                        </div>
                    </div>

                </form>
            </div>
        );
    }
}

export default TodoForm;