import React, { Component } from 'react';
import Todo from './Todo';
export default function (props) {

    let output = props.todos.map((c) => <Todo data = {c} changePriority = {this.props.changePriority} changeStatus = {this.props.changeStatus}/>);
    return (
        <div className='row'>
            {output}
            
        </div>
    );
}