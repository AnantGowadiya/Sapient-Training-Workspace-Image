import React, { Component } from 'react';
import './Todo.css'

class Todo extends Component {
    render() {
        let data = this.props.data;
        let classColor = '';
        let priorityText = 'Low'
        let statusColor = data.status === 'open' ? 'blue' : 'red';
        if (data.priority === 1) {
            classColor = 'yellow';
            priorityText = 'Low'
        }
        else if (data.priority === 3) {
            classColor = 'green';
            priorityText = 'Medium'
        }
        else {
            classColor = 'red';
            priorityText = 'High';
        }

        return (
            <div className="container">
                <div className="row">
                    <div className="col">{data.text}</div>
                    <div className="col">
                        <button
                            onClick={() => {

                                this.props.changeStatus(data._id);
                            }}
                            className={statusColor}>{data.status}</button>
                    </div>

                    <div className="col">
                        <button id='priority'
                            onClick={() => {

                                this.props.changePriority(data._id);
                            }}
                            className={classColor}>{priorityText}</button>
                    </div>
                </div>
            </div>

        );
    }
}

export default Todo;