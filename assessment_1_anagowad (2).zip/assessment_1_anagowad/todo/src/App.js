import React from 'react';
import ReactDOM from 'react-dom';
import { Component } from 'react';
import AppHeader from './components/Appheader';

import TodoForm from './components/TodoForm';
import TodoList from './components/TodoList';
// import Todo from './components/Todo';

import 'jquery';
import 'bootstrap/dist/css/bootstrap.css';
import 'bootstrap/dist/js/bootstrap';




var baseurl = 'http://localhost:4000/api/assessment1/';



class App extends Component {
  state = { todos: [], data: {} }
  constructor() {
    super(); // must invoke superclass constructor
    this.addTodo = this.addTodo.bind(this);
    this.changePriority = this.changePriority.bind(this);
    this.changeStatus = this.changeStatus.bind(this);
  }
  addTodo = (todo) => {
    // console.log({...todo});
    const options = {
      method: 'POST',
      body: JSON.stringify(todo),
      headers: {
        'Content-Type': 'application/json'
      }
    };

    fetch(baseurl, options)
      .then(resp => resp.json())
      .then(data => {
        let todos = [todo, ...this.state.todos];
        this.setState({ todos });
      });

  }
  changeStatus = (id) => {
    const options = {
      method: 'POST',
      body: JSON.stringify(id),
      headers: {
        'Content-Type': 'application/json'
      }
    };
    fetch(baseurl, options)
      .then(resp => resp.json())
      .then(data => {
        let todos = [...this.state.todos];
        let index = todos.findIndex((c) => c.id === id);
        todos[index].status = todos[index].status === 'open' ? 'open' : 'closed';
        this.setState({ todos });
      });
  }
  changePriority = (id, priorityNumber) => {
    const options = {
      method: 'POST',
      body: JSON.stringify(id),
      headers: {
        'Content-Type': 'application/json'
      }
    };
    fetch(baseurl, options)
      .then(resp => resp.json())
      .then(data => {
        let todos = [...this.state.todos];
        let index = todos.findIndex((c) => c.id === id);
        todos[index].priority = priorityNumber;
        this.setState({ todos });
      });
  }
  render() {
    return (
      <div>
        <title>Todo App</title>
        <AppHeader />
        <h1 className='text-center'>Todo App</h1>
        <TodoForm addTodo={this.addTodo} />
        <p></p>
        <TodoList todos={this.state.todos} changePriority = {this.changePriority} changeStatus = {this.changeStatus}/>
      </div>
    );
  }
}

export default App;